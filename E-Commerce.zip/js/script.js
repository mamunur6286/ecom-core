$(document).ready(function () {
    $('.menu-bar').click(function () {
        $('.main-menu ul').slideToggle();
    });
});
