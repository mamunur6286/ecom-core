<?php
    include_once "inc/header.php";
?>
    <section class="empty_page">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="404_page">
                    <h1 align="center">404</h1>
                    <p>Not Found!</p>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
    include_once "inc/footer.php";
?>